Hello!
  
  Thanks for downloaded trial-version of "FastReport for [x]Harbour".
  
  "FastReport for [x]Harbour"  is  a  report  generator  for giving [x]Harbour
application the ability to generate reports quickly and efficiently. "FastReport
for  [x]Harbour"  provides  all  the  tools that [x]Harbour developers need to
develop reports.

  "FastReport  for  [x]Harbour"  is based on excellent  "FastReport 4"  and
fully adapted for [x]Harbour at HB API level.

  Trial-version issues:
     - only 5 pages of the report is available�
     - the nag message showed if the main script of the report is present

  Data, reports and part of language resources for demo applications are included.

  To  use  "FastReport for [x]Harbour" in application simply add FASTREPH.PRG,
FASTREPH.CH  to  your  project. Copy FRSystH.dll in a convenient directory, for 
example, in directory with application exe-file.

  For full information about using this product, please, download user manuals.  


Spirin Sergey.
"Paritet Soft" Company.

Copyright:  Spirin Sergey, (c) 2006-2008. All rights reserved.
